SET SERVEROUTPUT ON;

BEGIN
    Retrieve_package.afiseaza_clienti;
    Retrieve_package.afiseaza_camere;
    Retrieve_package.afiseaza_detalii_camere;
    Retrieve_package.afiseaza_rezervari;
END;

select * from rezevare;

BEGIN
    Delete_package.DELETE_detalii_camera(4);
END;


BEGIN
   Delete_package.DELETE_rezervare(7);
END;

BEGIN
    Delete_package.DELETE_camera(4);W
END;

BEGIN
    Delete_package.DELETE_CLIENT(7);
END;

BEGIN
    Delete_package.DELETE_CLIENT(10);
END;

BEGIN
    Update_package.UPDATE_CLIENT_TELEFON(1, '0748689022');
END;

BEGIN
    Update_package.UPDATE_detalii_camera_pret(1, 270);
END;

DECLARE
    v_email_1 clienti.email%TYPE;
BEGIN
   v_email_1 := Returnare_email(5); 
   IF v_email_1 IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Email-ul clientului este: ' || v_email_1);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Clientul cu id-ul specificat nu exista.');
    END IF;
END;

DECLARE
    v_pret_1 detalii_camera.pret_noapte%TYPE;
BEGIN
   v_pret_1 := Returnare_pret(5); 
   IF v_pret_1 IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Pretul camerei este: ' || v_pret_1);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Camera cu id-ul specificat nu exista.');
    END IF;
END;



BEGIN
    Update_package.UPDATE_rezervare(4, 1, 5, TO_DATE('29.08.2024','DD.MM.YYYY'));
END;

--tranzactie 1
BEGIN
   Update_package.UPDATE_CLIENT_TELEFON(2, '0743322022');
    Update_package.UPDATE_detalii_camera_pret(2, 450);
    Update_package.UPDATE_rezervare(5, 2, 2, TO_DATE('15.09.2024','DD.MM.YYYY'));
    COMMIT;
END;


BEGIN
    Insert_package.insert_client(8,'Manuel','Celmare','0767369917','celmaremanuel@gmail.com',45);
    SAVEPOINT A;
    Update_package.UPDATE_CLIENT_TELEFON(8, '0767332217');
    Insert_package.insert_rezervare(7,4,450,TO_DATE('14.09.2024','DD.MM.YYYY'),TO_DATE('18.09.2024','DD.MM.YYYY'),8,8);
    SAVEPOINT B;
    Update_package.UPDATE_detalii_camera_pret(8, 340);
    Update_package.UPDATE_rezervare(7, 8, 8, TO_DATE('21.09.2024','DD.MM.YYYY'));
    COMMIT;
END;



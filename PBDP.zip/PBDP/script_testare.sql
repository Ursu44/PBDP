BEGIN
    Retrieve_package.afiseaza_clienti;
     Retrieve_package.afiseaza_camere;
    Retrieve_package.afiseaza_detalii_camere;
    Retrieve_package.afiseaza_rezervari;
END;

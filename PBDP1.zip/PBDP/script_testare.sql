BEGIN
    Retrieve_package.afiseaza_clienti;
    Retrieve_package.afiseaza_camere;
    Retrieve_package.afiseaza_detalii_camere;
    Retrieve_package.afiseaza_rezervari;
END;

select * from rezevare;

BEGIN
    Delete_package.DELETE_detalii_camera(1);
END;


BEGIN
   Delete_package.DELETE_rezervare(1);
END;

BEGIN
   Delete_package.DELETE_rezervare(4);
END;


BEGIN
    Delete_package.DELETE_camera(1);
END;

BEGIN
    Delete_package.DELETE_CLIENT(1);
END;

BEGIN
    Delete_package.DELETE_CLIENT(10);
END;

BEGIN
    Update_package.UPDATE_CLIENT_TELEFON(1, '0748689022');
END;

BEGIN
    Update_package.UPDATE_detalii_camera_pret(8, 320);
END;

DECLARE
    v_email_1 clienti.email%TYPE;
BEGIN
   v_email_1 := Returnare_email(5); 
   IF v_email_1 IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Email-ul clientului este: ' || v_email_1);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Clientul cu id-ul specificat nu exista.');
    END IF;
END;

DECLARE
    v_pret_1 detalii_camera.pret_noapte%TYPE;
BEGIN
   v_pret_1 := Returnare_pret(5); 
   IF v_pret_1 IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Pretul camerei este: ' || v_pret_1);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Camera cu id-ul specificat nu exista.');
    END IF;
END;


DECLARE
    v_numar1 NUMBER;
BEGIN
   v_numar1 := NumarZile(2); 
   IF v_numar1 IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Nuamrul de zile este de : ' || v_numar1);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Rezervarea cu id-ul specificat nu exista.');
    END IF;
END;
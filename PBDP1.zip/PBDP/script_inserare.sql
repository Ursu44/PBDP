BEGIN
    Insert_package.insert_client(1,'Ion','Popescu','0748689012','popescuion13@gmail.com',27);
    Insert_package.insert_client(2,'Mihai','Adumitroaiei','0778180012','adumiroaieiM@gmail.com',35);
    Insert_package.insert_client(3,'Gigi','Popa','0760185612','GigiP14@gmail.com',42);
    Insert_package.insert_client(4,'Andrei','Tudor','0758184312','TudorA32@gmail.com',29);
    Insert_package.insert_client(5,'Alexandru','Vicol','0738182112','vicolalexandru@gmail.com',21);
    Insert_package.insert_client(6,'Marin','Puscasu','0777369659','adumiroaieiM@gmail.com',32);
END;

SELECT * FROM CLIENTI;
DELETE FROM CLIENTI;

BEGIN
     Insert_package.insert_camera(8, 1);
    Insert_package.insert_camera(19, 2);
    Insert_package.insert_camera(23, 3);
     Insert_package.insert_camera(60, 4);
     Insert_package.insert_camera(51, 5);   
     Insert_package.insert_camera(40, 6);
     Insert_package.insert_camera(44, 7);
     Insert_package.insert_camera(12, 8);
END;

SELECT * FROM CAMERA;
DELETE FROM CAMERA;

BEGIN
     Insert_package.insert_detalii_camera(290,0,'standard',3,'DA','COMUN', 8);
     Insert_package.insert_detalii_camera(230,1,'standard',1,'DA','COMUN', 7);
     Insert_package.insert_detalii_camera(210,1,'standard',1,'DA','COMUN', 1);
     Insert_package.insert_detalii_camera(390,1,'deluxe',2,'DA','PROPRIU', 2);
     Insert_package.insert_detalii_camera(480,1,'apartament',4,'NU','PROPRIU', 3);
     Insert_package.insert_detalii_camera(550,5,'executiv',4,'DA','PROPRIU', 4);
     Insert_package.insert_detalii_camera(480,4,'standard',3,'NU','COMUN', 5);
     Insert_package.insert_detalii_camera(450,3,'deluxe',2,'DA','COMUN', 6);
END;

SELECT * FROM detalii_CAMERA;
DELETE FROM detalii_CAMERA;

BEGIN
      Insert_package.insert_rezervare(1,4,840,TO_DATE('14.09.2024','DD.MM.YYYY'),TO_DATE('18.09.2024','DD.MM.YYYY'),1,1);
      Insert_package.insert_rezervare(2,7,3360,TO_DATE('02.08.2024','DD.MM.YYYY'),TO_DATE('09.09.2024','DD.MM.YYYY'),3,5);
      Insert_package.insert_rezervare(3,3,900,TO_DATE('01.09.2024','DD.MM.YYYY'),TO_DATE('03.09.2024','DD.MM.YYYY'),4,6);
      Insert_package.insert_rezervare(4,3,630,TO_DATE('23.08.2024','DD.MM.YYYY'),TO_DATE('26.08.2024','DD.MM.YYYY'),5,1);
      Insert_package.insert_rezervare(5,5,780,TO_DATE('10.09.2024','DD.MM.YYYY'),TO_DATE('12.09.2024','DD.MM.YYYY'),2,2);
      Insert_package.insert_rezervare(6,4,840,TO_DATE('14.08.2024','DD.MM.YYYY'),TO_DATE('18.08.2024','DD.MM.YYYY'), 6,3);
END;

SELECT * FROM REZERVARE;
DELETE FROM REZERVARE;


